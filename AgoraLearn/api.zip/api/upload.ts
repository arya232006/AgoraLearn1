import express from 'express';
import { chunkText } from '../lib/chunk';
import { embedText } from '../lib/embeddings';
import { supabase } from '../lib/supabase';

const app = express();
app.use(express.json({ limit: '10mb' }));

app.post('/', async (req, res) => {
  try {
    const { text, docId } = req.body;
    if (!text || !docId) return res.status(400).json({ error: 'Missing text or docId' });

    const chunks = chunkText(text);

    for (const chunk of chunks) {
      const embedding = await embedText(chunk);
      const { error } = await supabase.from('chunks').insert([{ doc_id: docId, text: chunk, embedding }]);
      if (error) console.error('supabase insert error', error);
    }

    res.json({ ok: true, inserted: chunks.length });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

export default app;
