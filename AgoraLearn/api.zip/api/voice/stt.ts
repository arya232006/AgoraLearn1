import express from 'express';
import { agoraSTT } from '../../lib/agora';

const app = express();
app.use(express.json({ limit: '20mb' }));

app.post('/', async (req, res) => {
  try {
    const { audioBase64 } = req.body;
    if (!audioBase64) return res.status(400).json({ error: 'Missing audioBase64' });
    const buffer = Buffer.from(audioBase64, 'base64');
    const text = await agoraSTT(buffer);
    res.json({ text });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default app;
