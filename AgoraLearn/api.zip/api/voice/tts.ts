import express from 'express';
import { agoraTTS } from '../../lib/agora';

const app = express();
app.use(express.json({ limit: '5mb' }));

app.post('/', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'Missing text' });
    const audio = await agoraTTS(text);
    res.setHeader('Content-Type', 'audio/wav');
    res.send(audio);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default app;
