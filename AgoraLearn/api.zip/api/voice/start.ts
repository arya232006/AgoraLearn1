import express from 'express';
import { createAgoraSession } from '../../lib/agora';

const app = express();
app.use(express.json());

app.post('/', async (req, res) => {
  try {
    const session = await createAgoraSession();
    res.json(session);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default app;
