import express from 'express';
import { agoraSTT, agoraTTS } from '../../lib/agora';
import { runRAG } from '../../lib/rag';

const app = express();
app.use(express.json({ limit: '30mb' }));

app.post('/', async (req, res) => {
  try {
    const { audioBase64 } = req.body;
    if (!audioBase64) return res.status(400).json({ error: 'Missing audioBase64' });
    const audioBuffer = Buffer.from(audioBase64, 'base64');

    const transcript = await agoraSTT(audioBuffer);
    const { answer } = await runRAG(transcript);
    const audio = await agoraTTS(answer);

    res.json({ textAnswer: answer, audioBase64: audio.toString('base64') });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

export default app;
